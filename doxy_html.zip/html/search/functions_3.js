var searchData=
[
  ['fois',['fois',['../class_matrice.html#ad346685cc21bfc850b97d048f55e33d1',1,'Matrice']]]
];
