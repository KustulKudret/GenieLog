var searchData=
[
  ['opere',['opere',['../_arbre_8cpp.html#ab32af03f0920ed99596e0c31aca09d59',1,'Arbre.cpp']]],
  ['opere_5fmatrice',['opere_Matrice',['../_arbre_8cpp.html#a97157a7a98e827519f28618a40a8ac7a',1,'Arbre.cpp']]]
];
