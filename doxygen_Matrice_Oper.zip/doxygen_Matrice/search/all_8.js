var searchData=
[
  ['transposer',['transposer',['../class_matrice.html#a2b26c62f4edf8693f5a1c3211707685b',1,'Matrice']]]
];
