var searchData=
[
  ['matrice',['Matrice',['../class_matrice.html#af7ab54a435bc417e66910c34954e19e6',1,'Matrice::Matrice(int hauteur, int largeur)'],['../class_matrice.html#a7bfa52fc5792d3c31086d7713c2bdee4',1,'Matrice::Matrice(std::string nomFichier)']]],
  ['moins',['moins',['../class_matrice.html#ae6a11c90995860776b2016c418f3b75b',1,'Matrice']]]
];
